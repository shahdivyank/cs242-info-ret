////TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
//// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
//public class Main {
//    public static void main(String[] args) {
//        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
//        // to see how IntelliJ IDEA suggests fixing it.
//        System.out.printf("Hello and welcome!");
//
//        for (int i = 1; i <= 5; i++) {
//            //TIP Press <shortcut actionId="Debug"/> to start debugging your code. We have set one <icon src="AllIcons.Debugger.Db_set_breakpoint"/> breakpoint
//            // for you, but you can always add more by pressing <shortcut actionId="ToggleLineBreakpoint"/>.
//            System.out.println("i = " + i);
//        }
//    }
//}


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.io.FileWriter;
import org.json.JSONObject;


//https://www.indeed.com/jobs?q=java&l=USA, https://www.google.com/search?q=hello , https://github.com/search?q=webcrawler&type=repositories
//            // works : https://www.google.com/about/careers/applications/jobs/results , https://usccareers.usc.edu/search-jobs/developer?orgIds=1728-1209&kt=1
//            // https://inlandempire.craigslist.org/search/jjj?query=jobs#search=1~thumb~0~991

public class Main {
    // Track visited URLs
    private static final Set<String> visitedLinks = new HashSet<>();
    private static final Set<String> jobs = new HashSet<>();

    // user agent - essential for the webpage to allow us to crawl
    private static final String UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 (KHTML, like Gecko) Version/18.0 Safari/537.36";

    public static void main(String[] args) {
        String baseUrl = "https://www.google.com/about/careers/applications/jobs/results?page=";
        int i = 1;

        while (true) {
            String pageUrl = baseUrl + i;

            if (!crawlPage(pageUrl) ) {
                System.out.println("Crawled all pages. No more results found.");
                break;
            }
            i++;
        }
        System.out.println("Starting crawling for collected job links.");
        // info to extract - title , location
//        jobs.add("https://www.google.com/about/careers/applications/jobs/results/137054676544561862-staff-software-engineer-infrastructure-google-cloud-ai?page=123&pli=1");


//        for(String job : jobs) {
//            System.out.println(crawljobs(job));
//
//    }

        try (FileWriter writer = new FileWriter("crawled_jobs_output6.json")) {
            for (String job : jobs) {
                JSONObject result = crawljobs(job);  // Get the result of the crawl
                writer.write(result.toString(4));  // Write the output with a new line
//                System.out.println(result);
            }
            System.out.println("Output saved to crawled_jobs_output6.json");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


    private static JSONObject crawljobs(String job){

        try{
            Document d = Jsoup.connect(job).
                    userAgent(UA).
                    timeout(6000).
                    get();
            JSONObject jd = new JSONObject();
            String jobtitle = d.select("h2.p1N2lc").text();
            String loc = d.select("span.r0wTof").text();
            String app = d.select("a.WpHeLc.VfPpkd-mRLv6.VfPpkd-RLmnJb").attr("href");
            String qual = d.select("div.KwJkGe").text();
            String des = d.select("div.aG5W3").text();
            String resp = d.select("div.BDNOWe").text();
            jd.put("Title",jobtitle);
            jd.put("Location",loc);
            jd.put("Application link",app);
            jd.put("Qualification",qual);
            jd.put("Description",des);
            jd.put("Responsibility",resp);

            return jd;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



    private static boolean crawlPage(String url) {

        try {
            visitedLinks.add(url);
            Document doc = Jsoup.connect(url)
                    .userAgent(UA)
                    .timeout(6000)
                    .get();

            System.out.println("Crawling: " + url);
            if (doc.text().contains("No results")) {
                System.out.println(" no results found after this page");
                return false;
            }
            // Extract all job links on the page
            Elements links = doc.select("a[href]");

            boolean jobLinks = false; // To check if we got valid links

            for (Element link : links) {
                // absUrl-> gets the absolute link
                String absUrl = link.absUrl("href");
                //ensure that no job gets added twice
                if(!jobs.contains(absUrl) && absUrl.contains("google.com/about/careers/applications/jobs/results")) {
                    jobs.add(absUrl);
                    jobLinks = true;
                }
                // Collect only job-related links
//                if (!visitedLinks.contains(absUrl) && absUrl.contains("google.com/about/careers/applications/jobs/results")) {
//                    // visited links
//                    visitedLinks.add(absUrl);
//                    System.out.println("Found job link: " + absUrl);
//
//
//                }



            }
            // Continue crawling if job links were found
            System.out.println("Number of links " + jobs.size());
            return jobLinks;

        } catch (IOException e) {
            System.err.println("Error: Unable to fetch page " + url + " - " + e.getMessage());
            // Stop crawling if there is an error
            return false;
        }
    }
}
